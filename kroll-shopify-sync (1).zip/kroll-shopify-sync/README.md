# Kroll → Shopify Sync

Connects your Shopify store to Kroll International's wholesale API. Keeps inventory and pricing synced automatically, and drop-ships orders to customers when they buy.

Built for Todd's Sporting Goods.

## What It Does

**Inventory Sync (every 4 hours):**
Calls Kroll's `CheckProductAvailability` API for every Kroll-tagged SKU in your Shopify store. Updates stock levels and prices with your markup applied. Prevents overselling.

**Auto-Order (real-time):**
When a customer buys a Kroll product on your Shopify store, a webhook fires and automatically submits a drop-ship purchase order to Kroll via `SubmitPurchaseOrder`. The order ships directly from Kroll to your customer with no inventory on your end.

**SKU Lookup (manual):**
Hit `/api/check-sku?skus=ABC123,DEF456` to instantly see dealer cost, MSRP, stock levels, and your margin — useful for quoting departments.

## Architecture

```
┌─────────────┐     Cron (4hr)      ┌──────────────────┐
│   Shopify    │◄───────────────────│  Vercel Functions │
│   Store      │                    │                  │
│              │  Webhook (order)   │  sync-inventory  │
│              │───────────────────►│  webhook-order   │
└─────────────┘                    │  check-sku       │
                                   └────────┬─────────┘
                                            │ SOAP API
                                   ┌────────▼─────────┐
                                   │  Kroll API v2     │
                                   │  apiv2.krollcorp  │
                                   └──────────────────┘
```

## Important: Product Catalog

Kroll's API does NOT have a product catalog endpoint. It only checks availability for SKUs you already know. You need to get your product data (names, descriptions, images) into Shopify by one of these methods:

1. **CSV export from Kroll's dealer portal** — export products, import into Shopify
2. **FTP data feed** — ask your Kroll rep if they offer one: (586) 739-9200
3. **Manual entry** — for a curated selection of 200-500 SKUs your departments need

Tag all Kroll products with `kroll` in Shopify so the sync knows which ones to check.

## Setup

### 1. Kroll API Credentials

Log into your Kroll dealer portal. You need three things:
- **Dealer Account Number**
- **User ID**
- **Password**

If you can't find API access, call (586) 739-9200 and ask for EBusiness API credentials.

### 2. Shopify Custom App

1. Shopify Admin → **Settings → Apps → Develop apps**
2. Create app called "Kroll Sync"
3. Configure Admin API scopes:
   - `read_products`, `write_products`
   - `read_inventory`, `write_inventory`
   - `read_orders`, `write_orders`
   - `read_locations`
   - `read_fulfillments`, `write_fulfillments`
4. Install app → copy the **Admin API access token**

### 3. GitHub + Vercel

```bash
git init
git add .
git commit -m "Kroll Shopify sync"
git remote add origin https://github.com/YOUR_USERNAME/kroll-shopify-sync.git
git push -u origin main
```

Import to Vercel, add environment variables from `.env.example`.

### 4. Set Up Shopify Webhook (for auto-ordering)

Shopify Admin → Settings → Notifications → Webhooks:
- Event: **Order creation**
- URL: `https://your-app.vercel.app/api/webhook-order`
- Format: JSON

### 5. Test

```
# Health check
https://your-app.vercel.app/api/health

# Look up SKUs
https://your-app.vercel.app/api/check-sku?secret=YOUR_SECRET&skus=511-74369-019,QUIK-KP

# Trigger inventory sync manually
https://your-app.vercel.app/api/sync-inventory?secret=YOUR_SECRET
```

## Endpoints

| Endpoint | Trigger | Purpose |
|----------|---------|---------|
| `/api/health` | Manual | Check if credentials are configured |
| `/api/check-sku` | Manual | Look up SKU stock, cost, and your margin |
| `/api/sync-inventory` | Cron (4hr) | Sync stock + prices to Shopify |
| `/api/webhook-order` | Shopify webhook | Auto-order from Kroll on customer purchase |

## Costs

| Service | Cost |
|---------|------|
| Vercel Pro | $20/mo |
| Shopify Basic | $39/mo |
| **Total** | **~$59/mo** |

vs. Spark Shipping at $249/mo.

/**
 * POST /api/webhook-order
 * 
 * Shopify webhook: orders/create
 * When a customer buys Kroll products on your Shopify store,
 * this automatically submits a drop-ship PO to Kroll.
 * 
 * Setup in Shopify:
 *   Settings → Notifications → Webhooks → Create webhook
 *   Event: Order creation
 *   URL: https://your-app.vercel.app/api/webhook-order
 *   Format: JSON
 */

const crypto = require('crypto');
const { processOrder } = require('../lib/sync');

module.exports = async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'POST only' });
  }

  // Verify Shopify webhook signature
  const hmacHeader = req.headers['x-shopify-hmac-sha256'];
  if (process.env.SHOPIFY_WEBHOOK_SECRET && hmacHeader) {
    const rawBody = JSON.stringify(req.body);
    const hash = crypto
      .createHmac('sha256', process.env.SHOPIFY_WEBHOOK_SECRET)
      .update(rawBody, 'utf8')
      .digest('base64');

    if (hash !== hmacHeader) {
      console.error('Webhook signature mismatch');
      return res.status(401).json({ error: 'Invalid signature' });
    }
  }

  try {
    const order = req.body;
    console.log(`Processing Shopify order ${order.name} (${order.id})`);

    const result = await processOrder(order);
    console.log(`Order result:`, JSON.stringify(result));

    return res.status(200).json(result);
  } catch (err) {
    console.error('Webhook error:', err);
    return res.status(500).json({ status: 'error', error: err.message });
  }
};

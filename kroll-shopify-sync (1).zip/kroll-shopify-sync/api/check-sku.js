/**
 * GET /api/check-sku?secret=XXX&skus=SKU1,SKU2,SKU3
 * 
 * Manual endpoint to check product availability, dealer cost, and MSRP.
 * Useful for quoting departments before adding products to Shopify.
 */

const { checkProductAvailability } = require('../lib/kroll');
const { calcPrice } = require('../lib/shopify');

module.exports = async function handler(req, res) {
  const secret = req.query.secret;
  if (secret !== process.env.CRON_SECRET) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  const skuParam = req.query.skus;
  if (!skuParam) {
    return res.status(400).json({ error: 'Provide ?skus=SKU1,SKU2,SKU3' });
  }

  const skus = skuParam.split(',').map(s => s.trim()).filter(Boolean);
  if (skus.length === 0) {
    return res.status(400).json({ error: 'No valid SKUs provided' });
  }

  try {
    const results = await checkProductAvailability(skus);

    const enriched = results.map(item => ({
      sku: item.Sku,
      found: item.SkuFound,
      inStock: item.QuantityAvailable > 0,
      quantityAvailable: item.QuantityAvailable,
      dealerCost: item.DealerCost,
      msrp: item.SuggestedRetailPrice,
      yourSellPrice: item.SkuFound ? calcPrice(item.DealerCost, item.SuggestedRetailPrice) : null,
      margin: item.SkuFound
        ? `${((calcPrice(item.DealerCost, item.SuggestedRetailPrice) - item.DealerCost) / calcPrice(item.DealerCost, item.SuggestedRetailPrice) * 100).toFixed(1)}%`
        : null,
    }));

    return res.status(200).json({
      markup: `${process.env.MARKUP_PERCENT || 30}%`,
      results: enriched,
    });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
};

/**
 * GET /api/health
 * Verifies all required credentials are set.
 */
module.exports = async function handler(req, res) {
  const checks = {
    KROLL_DEALER_ACCOUNT: !!process.env.KROLL_DEALER_ACCOUNT,
    KROLL_USER_ID: !!process.env.KROLL_USER_ID,
    KROLL_PASSWORD: !!process.env.KROLL_PASSWORD,
    SHOPIFY_STORE_URL: !!process.env.SHOPIFY_STORE_URL,
    SHOPIFY_ACCESS_TOKEN: !!process.env.SHOPIFY_ACCESS_TOKEN,
    CRON_SECRET: !!process.env.CRON_SECRET,
    MARKUP_PERCENT: process.env.MARKUP_PERCENT || '30 (default)',
    KROLL_CONFIRM_EMAIL: process.env.KROLL_CONFIRM_EMAIL || '(not set)',
    KROLL_CONFIRM_NAME: process.env.KROLL_CONFIRM_NAME || '(not set)',
  };

  const required = ['KROLL_DEALER_ACCOUNT', 'KROLL_USER_ID', 'KROLL_PASSWORD',
    'SHOPIFY_STORE_URL', 'SHOPIFY_ACCESS_TOKEN', 'CRON_SECRET'];
  const allSet = required.every(k => checks[k] === true);

  return res.status(allSet ? 200 : 503).json({
    status: allSet ? 'ready' : 'missing_config',
    checks,
  });
};
